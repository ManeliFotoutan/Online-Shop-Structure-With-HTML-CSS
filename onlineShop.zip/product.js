// cart.js

document.addEventListener("DOMContentLoaded", function () {
    const cartItems = [];
    const cartItemsList = document.getElementById("cart-items");
    const cartTotal = document.getElementById("cart-total");

    function updateCart() {
        cartItemsList.innerHTML = "";
        let total = 0;

        cartItems.forEach(item => {
            const cartItem = document.createElement("li");
            cartItem.className = "cart-item";
            cartItem.innerHTML = `
                <span class="cart-item-name">${item.name}</span>
                <span class="cart-item-price">$${item.price.toFixed(2)}</span>
            `;
            cartItemsList.appendChild(cartItem);
            total += item.price;
        });

        cartTotal.textContent = `Total: $${total.toFixed(2)}`;
    }

    document.querySelectorAll(".cart-btn").forEach(btn => {
        btn.addEventListener("click", function () {
            const productBox = this.closest(".box");
            const productName = productBox.querySelector(".content h3").textContent;
            const productPrice = parseFloat(productBox.querySelector(".content .price").textContent.replace("$", ""));

            cartItems.push({ name: productName, price: productPrice });
            updateCart();
        });
    });
});
